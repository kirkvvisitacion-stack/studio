---
name: goodcup-look
description: Use when making anything in the Good Cup look, such as a post, carousel, Story, deck, report, poster, one-page document, web piece or video title card. Gives the colours, type, spacing, layout habits and a short checklist so the result looks like Good Cup and not like a default AI page.
---

# The Good Cup look

Good Cup is a specialty coffee company in the Philippines. The look is white and calm, with real photos and plain words. It should never read as "made by AI".

Read this file first. Then open `tokens/gc-tokens.css` and paste it into the page you build (inline, so it works on any laptop). Before you show anything, go through `checklist.md`.

## 1. Colour

Good Cup White carries the page. Crema is the warm second ground. Robusta is the text colour. Everything else is an accent, and one accent per piece is plenty.

| Name | Hex | Use |
|---|---|---|
| Good Cup White | #FFFFFF | main ground |
| Crema | #EDE9E4 | second ground, panels |
| Cashew | #D1C8C1 | thin rules and borders |
| Robusta | #46362B | text on white or crema |
| Black | #000000 | strong text, buttons, dark grounds |
| Espresso ground | #241B16 | dark ground (never pure grey) |
| Espresso card | #2E221B | card on the dark ground |
| Butterscotch deep | #A9641F | step numbers and small labels on white |
| Butterscotch | #E3A36E | fill, or text on a dark ground only |
| Dulce coral | #F28778 | fill, or text on a dark ground only |
| Morning sky, Mint green, Blush petal, Lilac | #78BADE, #91CFB0, #F091B0, #C494C2 | accent fills, one per piece |

Rules: text on white is Robusta or Black. Coral and Butterscotch are never text on Crema (too faint). Gradients are not used, except a dark scrim over a photo. No purple or blue washes.

## 2. Type

- Brand face: Good Sans (a licensed font, not included in this pack, see `fonts/README.txt`).
- On the web and in claude.ai Artifacts, use DM Sans as the stand-in. Declare it like this: `font-family: "Good Sans","DM Sans",system-ui,sans-serif`.
- Headlines depend on the surface:
  - Team documents, reports, Artifacts: Good Sans (DM Sans) Bold.
  - Carousels, Stories, video titles, editorial web pages: a serif headline (Iowan Old Style, falls back to Georgia).
- Body is 16px on the web, regular weight, line height 1.5.
- Sentence case everywhere. No ALL CAPS labels, no letter-spaced labels, no Title Case headlines. A coffee's name keeps its own capitals, as on the bag.
- No italic word inside a headline for emphasis. Use weight or colour.
- Copy uses straight quotes and plain hyphens. No em dashes.

## 3. Layout and shape

- Left-aligned text. Centre only a single line that earns it.
- Content sits on the ground, separated by thin Cashew rules. Avoid rows of identical white rounded cards.
- Corners: 2px on web controls, 12px on a card when a card is needed. Pill shapes only on a website button.
- No coloured left border as a callout. Say it in the text.
- Tap targets are at least 44px. No sideways scroll at 375px wide.
- Motion: one quiet entrance on the hero, or none. Hover is an underline or a colour change at 140ms. No growing cards, no confetti, no word-by-word fades.

## 4. Photos and pictures

- Use real Good Cup photography. If you have none, leave a marked photo slot that asks for one. Never use stock photos or AI-made people.
- A piece with no photo at all is a flat white or crema page with a serif headline, which is exactly the default AI look. Add a photo or use the coffee's own label colour as a flat field.
- Icons are simple line icons (Lucide style) placed beside words, never in place of words, and never emoji.
- Never draw or invent a sticker, label, bag word or price. Use the real artwork file.
- Do not label a sent piece with how it was made ("AI", "real photo", "3D scan"). File names are a number plus a description.

## 5. Words

- Plain short sentences, the way a person at the cafe would say it.
- No invented numbers, producers, prices or scores. If a fact is missing, leave a marked blank.
- Avoid "artisanal", "handcrafted", "premium", "elevate your coffee journey". Name the producer, the place, the altitude, the year.
- Prices are bare numerals, or a peso sign. Do not put a currency code before the number on customer pieces.
- Never put build notes, sources or "open questions" on a piece that goes to the team.

## 6. Steps to follow

1. Say which surface it is (post, deck, report, web page, video title).
2. Paste `tokens/gc-tokens.css` into the page.
3. Build on a White or Crema ground with one accent.
4. Add a real photo or a marked photo slot.
5. Run `checklist.md` line by line and fix every miss.
6. Show the result at desktop width and at phone width (375px).

## 7. What this pack does not have

The font files, the photo library, the sticker and bag render method, and the automated checker script that the Good Cup design owner runs are not in this pack. If a piece needs one of them, say so and ask the team lead.
