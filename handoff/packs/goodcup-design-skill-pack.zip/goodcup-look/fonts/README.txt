Good Sans font files are not in this pack. They are licensed and stay inside Good Cup.

If you need Good Sans (print, slides, Canva, video), ask the team lead for the font files.

On the web and in Artifacts, use DM Sans (free, from Google Fonts) as the stand-in.
Do not upload Good Sans to a public website or a public page.
