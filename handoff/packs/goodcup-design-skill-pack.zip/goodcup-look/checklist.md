# Good Cup checklist, in plain words

Go through every line before you show a piece. A "no" means fix it first.

## Shape and layout
1. No uppercase, boxed, letter-spaced tag used as a label? (yes means fix)
2. Corners square or lightly rounded, pills only on a website button?
3. Is the content on the ground with thin rules, not rows of identical white rounded cards?
4. No coloured left-border callouts?
5. Text left-aligned, not everything centred?

## Colour
6. Ground is white or crema? Text is Robusta or black?
7. Coral or Butterscotch never used as text on Crema?
8. No gradients (except a dark scrim over a photo), no glass blur panels?
9. Every colour comes from the token file, none made up?

## Type
10. Headlines are sentence case, not Title Case or ALL CAPS?
11. Good Sans or DM Sans for the brand face. Serif only for carousel, Story, video title and editorial web headlines.
12. No italic word inside a headline?
13. No smart quotes, no em dashes, no decorative symbols in copy?
14. Step numbers on white use Butterscotch deep, not plain Butterscotch.

## Pictures
15. Is there a real photo (or a marked photo slot)? Text-only pieces are the exception.
16. No emoji used as icons or numbers?
17. No invented sticker, label or bag text?
18. No "AI", "real photo" or "3D scan" tag on a sent piece or file name?

## Motion
19. Hover uses an underline or colour change, not a growing card?
20. No confetti, sparks or bursts? Words readable from the first frame (video and Stories)?

## Words
21. No invented numbers, prices, producers or scores?
22. No "artisanal", "handcrafted", "premium"?
23. No build notes or sources on a team piece?

## Last look
24. Open it at 375px wide: no sideways scroll, tap targets 44px or more.
25. Does it still look like Good Cup if you cover the logo? If it looks like any other AI page, add a real photo and remove decoration.
