# Good Cup look, skill pack

Teaches your Claude to make things in the Good Cup look: colours, type, layout habits and a 25-line checklist.

## What is inside
- SKILL.md: the look in one page (Claude reads this first)
- checklist.md: 25 yes/no checks before you show a piece
- tokens/gc-tokens.css: colours, type, spacing, corners, motion, ready to paste into a page
- fonts/README.txt: where to get Good Sans (the font files are not in this pack)

## Install in claude.ai (about 1 minute)
1. Open claude.ai and sign in.
2. Go to Settings, then Capabilities, then Skills.
3. Choose Upload skill and pick goodcup-design-skill-pack.zip.
4. Switch the skill on. Start a new chat and say: "Use the goodcup-look skill to make a one-page flyer."

## Install in Claude Code (about 1 minute)
1. Unzip the pack. You get a folder called goodcup-look.
2. Copy that folder into ~/.claude/skills/ so the file ~/.claude/skills/goodcup-look/SKILL.md exists.
3. Start a new Claude Code session and say: "Use the goodcup-look skill to make a one-page flyer."

Cowork uses the same Skills screen as claude.ai.

## Check it worked
Ask Claude: "Which skills do you have for Good Cup?" It should name goodcup-look. A page it builds should have a white ground, Robusta text, sentence case headlines and no pills, gradients or emoji.

## Not in this pack
Good Sans font files (licensed), the real photo library, the sticker and bag render method, and the checker script the design owner runs. The web look uses DM Sans instead of Good Sans, so a page will be close but not letter-perfect.

## Need help
Ask the Good Cup team lead.
