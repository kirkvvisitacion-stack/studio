Bag maker - team pack

Drop in the sticker PDF. Get the bag pictures. Nothing to install.

Open it: https://kirkvvisitacion-stack.github.io/goodcup-bagmaker/
About 5 minutes.

How to use it
1. Get the sticker PDF
   In Canva, download the sticker as PDF Print. Keep the Canva file name, for
   example 26-112_Finca-de-Garces_PH-3x3.pdf. The page reads the control
   number and coffee name from it.
2. Drop it into step 1
   Drag the PDF onto the box, or tap it to choose the file. Read the control
   number and the coffee name. Fix them if they are wrong, because they
   become the file names.
3. Pick the bag and press Make
   The page picks the bag from your sticker. Check it: yellow sides for
   Philippine coffees, white for seasonal, brown for all year round, black
   for Rare. Then press Make the bag. The first bag takes a minute, after
   that about 5 seconds.
4. Read every word
   Look at the front picture next to your sticker. Read each word on both.
   Tick the box only when they match.
5. Save it to the NAS
   Press Download the folder, unzip it, and upload the whole folder to the
   inbox below. Then copy the team message from the page and send it in the
   team chat.

Before you start
- The sticker as a print PDF from Canva (3x3, or 4x3 for 500 g and 1 kg)
- Chrome or Safari on a computer
- Your NAS login, to hand in the folder

What you get
- 01 Front, 02 Angled, 03 45 Degrees, 04 Back (PNG pictures)
- 06 Extras: the 3D model, the front cutout, the shadow layer
- 07 The sticker PDF you used

Hand it in here
01 New Bags - Studio Look Library / 18 New Sticker Bags - Inbox / 2 Finished bags (pick up here)
Upload only into folder 18. Never move, rename or delete anything else on the NAS.

If something looks wrong
- The page says the sticker needs a check
    Read the note under the sticker. If it mentions a dark edge on a black
    bag, send the sticker and a screenshot to the team chat before you use
    the pictures.
- The bag size I need is not listed
    The page makes 200 g, 500 g and 1 kg (yellow, white, brown sides), 100
    g Rare and 50 g Rare. Anything else, ask Kirk.
- The first bag is slow
    The first bag of each type downloads about 40 MB. Keep the tab open.
    The next ones take seconds.
- A word on the bag looks different from the sticker
    Do not tick the box. Send the sticker and a screenshot to the team
    chat.
- There is no 360 video
    Right, it is not on the page yet. Ask Kirk if you need one.

Still stuck?
Send a screenshot to the team chat, or message Kirk on Telegram at @kirkvee.
Say which step you are on and what you see.

In this pack:
- README.txt (this file)
- one-page-guide.html (open it and print it)
- HANDOFF.md (for whoever looks after the tool)
