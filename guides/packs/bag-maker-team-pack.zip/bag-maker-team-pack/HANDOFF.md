# Bag maker handoff

For whoever looks after the tool. Nobody else needs this file.

## How it works in 10 lines
1. The live page is a static site on GitHub Pages (repo goodcup-bagmaker, Pages from main). No server, no upload.
2. For each bag type, 9 calibration stickers (flat greys, sin and cos fringes, ramps) are rendered once in Blender with the delivered look (bake_calib.py).
3. decode.py turns those renders into per-pixel sticker coordinates plus a linear gain and offset.
4. pack.py adds the floor, ambient occlusion and grain at the delivered exposure gain (GAIN_LOCK) and writes the data folder.
5. In the browser, pdf.js 4.10.38 (vendored) rasterises the sticker PDF with print intent and glyphs as paths, at offset -0.5 / -0.25 px.
6. A Pillow-exact Lanczos port (pilresize.js) resizes it, and engine.js rebuilds only the sticker zone of the bag.
7. The page swaps the GLB front texture and zips the files with the deliver_sides.py names.
8. Bag types live: 200 g, 500 g, 1 kg with yellow, white or brown sides, 100 g Rare and 50 g Rare (data keys such as 200_yellow, 100_black, 50_black).
9. Proof on file: page against Blender on 5 real stickers, median 0, p99 2 to 4 levels. engine.js matches its Python reference with 0 differing values. The GLB passes the Khronos validator.
10. The only known difference is the text edge: pdf.js rasterises it slightly differently from poppler.

## Where things live
- Source: the bagmaker folder inside the New Coffee Bags project, under 90 Working Files. The site folder inside it is the git repo.
- Bake and build scripts: bake_calib.py, decode.py, pack.py, site_index.py, kernel_fit.py, and the bake_*.sh runners.
- Tests: the tests folder (test_engine.mjs, test_pilresize.mjs, widget_test.html, the test stickers).
- Proof log: truth.log (each bag type against a Blender render of a real sticker, median about 1).

## How to add a bag type
1. Get the new bag form into the Blender file. This needs Blender on a Mac. New bag shapes cannot be made on the web page.
2. Run bake_calib.py for the new type.
3. Run decode.py, then pack.py. The new folder appears in site/data.
4. Run site_index.py so data/index.json lists it, and add its size and side buttons if the page needs them.
5. Check it with a real sticker against a Blender render, as truth.log does.
6. Commit and push, then run the live checks below.

## How to fix a font problem
- Bag maker has no live fonts. Words on the bag come from the sticker PDF, so a font problem is a sticker problem: ask the designer to re-export the PDF from Canva as PDF Print.
- If words look wrong only in the page, compare with a poppler render of the same PDF. The text edge difference above is expected; a missing or swapped glyph is not.

## What must not be changed
- GAIN_LOCK and the delivered exposure gain.
- The vendored pdf.js 4.10.38 and its offsets (-0.5 / -0.25 px).
- The Lanczos port. It matches Pillow on purpose.
- The baked files in data. Re-bake them, never edit them.
- Do not put secrets, NAS addresses or licensed files in the repo. It is public.
- Do not overwrite a delivered file without keeping the old one as v1.

## Live checks after every change
1. Open the live page. It loads with no error in the browser console.
2. Make a bag from a square test sticker. Test with exactly 1800 x 1800 pixels or a PDF. A PNG of 1800 x 1801 fails for reasons a PDF never has.
3. Compare the front with a Blender render: median 1 or less.
4. Download the zip. It holds 01 Front, 02 Angled, 03 45 Degrees, 04 Back, 06 Extras and 07 the sticker PDF.
5. Check the pushed files by comparing the git hash with the live hash, then curl the live page.
6. Check the page at 375 px wide and at 1280.

## Known gaps
- No 360 turn video (about 12 hours of baking on a Mac).
- No new bag forms without Blender.
- A dark-edged sticker on a black bag shows a warning.

## Who to ask
Kirk on Telegram, @kirkvee.
