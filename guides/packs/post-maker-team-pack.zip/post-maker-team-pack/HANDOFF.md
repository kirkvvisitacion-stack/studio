# Post maker handoff

For whoever looks after the tool. Nobody else needs this file.

## How it works in 10 lines
1. The live page is a static site on GitHub Pages (repo goodcup-post-maker, public, noindex). No server.
2. Everything runs in the visitor's browser. Photos and fonts never leave it.
3. js/render.js has one drawing routine (drawSlide). The preview and the downloaded PNGs both use it, so they always match.
4. The text baseline is snapped with Math.floor to match Chrome's DOM text. Parity with the approved Closed Mon-Wed slides is 0,0 offset.
5. js/fonts.js loads Good Sans. The font files are licensed, so they are never on the site.
6. Each person loads the 16 files (or the NAS zip) once. They stay in that browser's IndexedDB, or load from the computer if Good Sans is installed.
7. Weights follow the file names: Heavy is 800 and Black is 900, as in the Slow Bar editor.
8. js/app.js is the page logic and the text rules. js/zip.js reads and writes zips.
9. Download is one zip: Carousel (1080x1350) and Story (1080x1920) folders, 00 Caption.txt, and a .gcpost project file that reopens the post.
10. Opened projects are cleaned (cleanHTML and a content security policy), file names are sanitised, and autosave waits until the saved post is read back.

## Where things live
- Source: the site folder of the Post Maker, inside the Good Cup Studio project (03 Post Maker/site). It is the git repo.
- Files: index.html, guide.html, js/app.js, js/render.js, js/fonts.js, js/zip.js, assets/.
- Tests: 90 Working Files/tests. parity.html must say PASS before any push. The fixtures include a Good Sans zip that must never be pushed.

## How to fix a font problem
1. Read the file name rule in js/fonts.js: a name like GoodSans-BoldItalic.otf maps to family, weight and style.
2. If a weight looks wrong, check the name of the font file first, not the code.
3. A browser with cleared data needs the 16 files loaded again. That is expected.
4. Iowan Old Style comes from Mac and iPhone only. On Windows and Android the page uses Good Sans.
5. After any font change, run parity.html and look at one slide at 100 percent.

## What must not be changed
- The single drawing routine in render.js. Never draw the preview and the export separately.
- The Math.floor baseline snap.
- The rule that no font file goes in the repo. Check the push for .otf, .ttf and .zip files.
- The weight mapping (Heavy 800, Black 900).
- Do not put secrets, NAS addresses or personal details in the repo. It is public.
- Do not replace a delivered post file. Keep the old one as v1.

## Live checks after every change
1. Run 90 Working Files/tests/parity.html. It must say PASS.
2. Open the live page with no error in the console.
3. Load fonts, add a photo, type words, download. Open the zip and look at one carousel slide and one Story slide.
4. Open the .gcpost file again with Open project file.
5. Check the push: compare git ls-remote with HEAD, then curl the live page.
6. Check at 375 px and at 1280 px.

## Known gaps
- Not tested on a real iPhone or Android yet, only the 375 px emulation.
- HEIC photos open in Safari only.
- The page does not yet warn when words sit on a busy part of the photo.

## Who to ask
Kirk on Telegram, @kirkvee.
