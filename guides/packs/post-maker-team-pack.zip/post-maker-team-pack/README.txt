Post maker - team pack

Make an Instagram carousel and Story in the Good Cup look, right in the browser.

Open it: https://kirkvvisitacion-stack.github.io/goodcup-post-maker/
About 10 minutes the first time.

How to use it
1. Load the fonts, once
   The Good Cup font is on the NAS. Download all 16 files, then press Choose
   font files in the post maker and pick them. You do this once on each
   computer. The green line Good Cup fonts ready means you are set.
2. Add your photos
   Press Add photos and pick one photo per slide, in posting order. Drag a
   photo to choose which part shows. Carousel and Story are framed
   separately, so check both.
3. Write the words
   Type in the words box. To make some words bold or italic, select them
   first, then press the button. Drag the words to move them, and keep them
   off busy parts of the photo.
4. Read every slide and download
   Name the post, paste the caption, then read each slide in Carousel and
   Story. Check that every date matches its day. Tick the box and press
   Download the post.
5. Save it to the NAS
   Unzip the download and upload the whole folder to the inbox below. Then
   copy the team message from the page and send it in the team chat.

Before you start
- Your photos, one per slide
- The Good Sans font files from the NAS (first time only)
- Chrome or Safari on a computer or phone
- Your NAS login, to hand in the folder

What you get
- One zip with a Carousel folder (1080x1350) and a Story folder (1080x1920)
- 00 Caption.txt with your caption
- A .gcpost project file, so anyone can reopen and edit the post

Hand it in here
01_Final_Outputs / Photos / 00 Post Maker - Inbox
Upload only into that folder. Never move, rename or delete anything else on the NAS.

If something looks wrong
- It says fonts are missing
    Do step 1 again. On a computer that already has Good Sans installed,
    the fonts load by themselves.
- My iPhone photo does not open
    HEIC photos open in Safari. In other browsers, save the photo as a JPG
    first.
- I want to fix a post later
    Press Open project file and pick the .gcpost file from the post
    folder.
- Someone else should finish it
    Send them the .gcpost file. It keeps the photos, words and positions.
- Iowan looks wrong on my laptop
    Iowan comes with Mac and iPhone. On Windows or Android, use Good Sans.
- Where do my photos go?
    Nowhere. Everything happens in your browser. Only the files you
    download leave it.

Still stuck?
Send a screenshot to the team chat, or message Kirk on Telegram at @kirkvee.
Say which step you are on and what you see.

In this pack:
- README.txt (this file)
- one-page-guide.html (open it and print it)
- HANDOFF.md (for whoever looks after the tool)
